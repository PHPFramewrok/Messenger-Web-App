// JavaScript Document

function submitForm()
{
	var form = document.getElementById("registerForm");
	form.submit();
}