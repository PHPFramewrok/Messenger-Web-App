<?php
$servername = "localhost";
$username = "andrew";
$password = "T9pzPzX7WF42vMQd";
$dbname = "MessengerUsers";

$fname = $_POST["fname"];
$lname = $_POST["lname"];
$email = $_POST["email"];
$uname = $_POST["uname"];
$upassword = $_POST["password"];

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO MessengerUsers (fname, lname, email, uname, upassword) 
VALUES ('Hello!', '" . $lname . "', '" . $email . "', '" . $uname . "', '" . $upassword ."')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>